/* get cart total from session on load */
updateCartTotal();

/* button event listeners */
document.getElementById("emptycart").addEventListener("click", emptyCart);
var btns = document.getElementsByClassName('addtocart'); 
for (var i = 0; i < btns.length; i++) {
    btns[i].addEventListener('click', function() {addToCart(this);});
}

/* ADD TO CART functions */

function addToCart(elem) {
    //init
    var sibs = [];
    var getprice;
    var getproductName;
    var cart = [];
     var stringCart;
    //cycles siblings for product info near the add button
    while(elem = elem.previousSibling) {
        if (elem.nodeType === 3) continue; // text node
        if(elem.className == "price"){
            getprice = elem.innerText;
        }
        if (elem.className == "productname") {
            getproductName = elem.innerText;
        }
        sibs.push(elem);
    }
    //create product object
    var product = {
        productname : getproductName,
        price : getprice
    };
    //convert product data to JSON for storage
    var stringProduct = JSON.stringify(product);
    /*send product data to session storage */
    
    if(!sessionStorage.getItem('cart')){
        //append product JSON object to cart array
        cart.push(stringProduct);
        //cart to JSON
        stringCart = JSON.stringify(cart);
        //create session storage cart item
        sessionStorage.setItem('cart', stringCart);
        addedToCart(getproductName);
        updateCartTotal();
    }
    else {
        //get existing cart data from storage and convert back into array
       cart = JSON.parse(sessionStorage.getItem('cart'));
        //append new product JSON object
        cart.push(stringProduct);
        //cart back to JSON
        stringCart = JSON.stringify(cart);
        //overwrite cart data in sessionstorage 
        sessionStorage.setItem('cart', stringCart);
        addedToCart(getproductName);
        updateCartTotal();
    }
}
var totPrice=0;
var prods="";

/* Calculate Cart Total */
function updateCartTotal(){
    //init
    var total = 0;
    var price = 0;
    var items = 0;
    var productname="" ;
    var carttable = "";
    
    

    if(sessionStorage.getItem('cart')) {
        //get cart data & parse to array
        var cart = JSON.parse(sessionStorage.getItem('cart'));
        //get no of items in cart 
        items = cart.length;
        //loop over cart array
        prods= productname
        for (var i = 0; i < items; i++){
            //convert each JSON product in array back into object
            var x = JSON.parse(cart[i]);
            //get property value of price
            price = parseFloat(x.price.split('R')[1]);
            productname = x.productname;
            //get product to the array
            
            
            prods= prods+productname+" , ";
            
            
            console.log(prods);
                
            //add price to total
            carttable += "<tr><td>" + productname + "</td><td>R" + price.toFixed(2) + "</td></tr>";
            total += price;
        }

        totPrice=total.toFixed(2);
        
        
        
        
    }
    //update total on website HTML
    document.getElementById("total").innerHTML = total.toFixed(2);
    //insert saved products to cart table
    document.getElementById("carttable").innerHTML = carttable;
    //update items in cart on website HTML
    document.getElementById("itemsquantity").innerHTML = items;

    
}
//user feedback on successful add
function addedToCart(pname) {
  var message = pname + " was added to the cart";
  var alerts = document.getElementById("alerts");
  alerts.innerHTML = message;
  if(!alerts.classList.contains("message")){
     alerts.classList.add("message");
  }
}
/* User Manually empty cart */
function emptyCart() {
    //remove cart session storage object & refresh cart totals
    if(sessionStorage.getItem('cart')){
        sessionStorage.removeItem('cart');
        updateCartTotal();
      //clear message and remove class style
      var alerts = document.getElementById("alerts");
      alerts.innerHTML = "";
      if(alerts.classList.contains("message")){
          alerts.classList.remove("message");
      }
    }
}
function remove()
{
    cart = cart.filter((item)=>item.id != id)

    updateCartTotal();
}
function checkOut()
{
    if(totPrice==0)
    {
        swal("Checkout Error", "No item was added to cart", "error");
        return false;
    }
    else
    {
    
    window.location.href="checkout.html?Price=" +totPrice+ ""
    }

    console.log(totPrice)
    
}

function finalPrice()
{

    const query = window.location.search
    const url = new URLSearchParams(query)
   
    const price = url.get("Price")
    const shipfee=100.00;
   
    document.getElementById('subtotal').innerHTML = price;
    document.getElementById('check-amt').innerHTML = (parseFloat(price)+shipfee).toFixed(2).toString();
    var vat = 15/100 *(parseFloat(price)+shipfee).toFixed(2)
     document.getElementById('vat').innerHTML = vat.toFixed(2);


    

}
function displayCart()
{
  //function to dispalyProducts from database

   

   db.collection("products").onSnapshot((info)=>{
        var html=""
        var div=""
        const list = document.getElementById("productcont");


        info.forEach(element => {
         
            div=`<div class="product col-lg-3 col-md-3 mb-5">
            <div class="prod">
              <img src="${element.data().Prod_pic}" alt="">
            </div>
           
              <h3 class="productname">${element.data().Prod_name}</h3>
             
              <p class="price">${element.data().Prod_price}</p>
              <button class="addtocart">Add To Cart</button>
          </div>`
        html += div ;
        list.innerHTML=html;

       
       
           
        });
    })
    
}
  

function makePayment()
{
    

    var name = document.getElementById("name").value;
    var phone = document.getElementById("phone").value;
    var address = document.getElementById("address").value;
    var city = document.getElementById("city").value;
    var prov = document.getElementById("prov").value;
    var zipcode = document.getElementById("zipcode").value;
    var amtPaid = document.getElementById("check-amt").innerText;
    let ref=(Date.now() + Math.random());

    

    var today = new Date();
    var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date+' '+time;
    var order = 1000;
    
    
   
        db.collection("orders").add({
            Order_No:  order,
            Name: name,
            Phone_number: phone,
            Address: address,
            City: city,
            Province: prov,
            Zip_code: zipcode,
            AmountPaid: amtPaid,
            PaymentDate: dateTime,
            Status: "Pending",
            Products: prods.slice(0, prods.length-2),        
            Reference: ref
        
        }).then(()=>{
            swal("Payment Completed","Your payment was succesfully made, Ref: "+ref, "success");
          })     
   


//send payment to db



}

function displayProduct()
{
   

   db.collection("products").onSnapshot((info)=>{
        var html=""
        var div=""
        const list = document.getElementById("productcont");


        info.forEach(element => {
            
        div=`<div class="product col-lg-4 col-md-4 mb-5">
        <div class="prod_img">
          <img src="${element.data().Prod_pic}" alt="">
        </div>
          <h4> ${element.data().Prod_name}</h4>
          <span>${element.data().Description}</span>
         
          <p> ${element.data().Prod_price}</p>
          <button data-toggle="modal" data-target="#myModal" class="updateProd" onclick="viewEachProduct('${element.id}')">Update</button>
          <button class="deleteProd" onclick="deleteProduct('${element.id}')">Remove</button>
          
      </div>`
        html += div ;
        list.innerHTML=html;

      
           
        });
    })
}

