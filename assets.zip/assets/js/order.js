
const price = parseFloat(document.getElementById("prc").innerText);

function increase(){
      var qty = parseInt(document.getElementById("hair2").value)+parseInt(1);     
                
      var finalPrice = price*qty;
 
      document.getElementById("prc").innerHTML = finalPrice.toFixed(2);
     

}  




