
      {
        db.collection("appointment").add({
          Name: name,
          Email_address: email,
          Phone_number: phone,
          Date: app_date,
          Hairdresser_name: hairdresser,
          Message: message
      
      }).then(()=>{
          swal("Successful", "Your message has been sent", "success");
      })     
      }