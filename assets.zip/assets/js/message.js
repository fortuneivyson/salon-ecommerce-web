function sendAppointment()
{
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var phone = document.getElementById("cphone").value;
    var app_date = document.getElementById("date").value;
    var hairdresser = document.getElementById("hairdresser").value;
    var message = document.getElementById("msg").value;
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var phoneno =  /^0(6|7|8){1}[0-9]{1}[0-9]{7}$/;
    var validName = /^[A-ZA-z]+$/;
    
    var today = new Date();
    var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date+' '+time;
    var status = "Waiting for Confirmation"
    
    

    
    let ref=(Date.now() + Math.random().toString(36))
    

    

    if(name!=""&&email!=""&&phone!=""&&app_date!=""&&hairdresser!=""&&message!="")
    {
      
     
     
      if(new Date(app_date).getDay()==6)
      {
        swal("Date Error", "We are not working on Saturdays", "error");

        return false;
      }
      if(new Date(app_date).getDay()==0)
      {
        swal("Date Error", "We are not working on Sundays", "error");

        return false;
      }
      
      if (name.length<2)
      {
        swal("Input Error", "Name must be more than one character", "error");
        
        
      return false;

      }
      
      if (!validName.test(name))
      {
        swal("Input Error", "Invalid name, ensure the are white spaces and digits", "error");
        
        
      return false;

      }
      

      if (!email.match(mailformat)) 
      {
        swal("Input Error", "Invalid email address", "error"); 
        return false;
      }
      
      

      if (!phone.match(phoneno)) 
      {
        swal("Input Error", "Invalid phone number", "error"); 
        return false;
      }
      
     
      if (message.length==0)
      {
      swal("Input Error", "No message was typed", "error");
      return false;
      }
      

      else
      {
        {
          db.collection("appointment").add({
            Name: name,
            Email_address: email,
            Phone_number: phone,
            Appointment_Date: app_date,
            Hairdresser_name: hairdresser,
            Message: message,
            Date_apt_created: dateTime,
            Reference: ref,
            Status: status
        
        }).then(()=>{
          swal("Appointment Made","Appointment succesfully completed, Ref: "+ref, "success");
        })     
        }
        
        
        
        return true;

        
      }
   
}
else
{

 swal("Missing Input","All Fields Are Required", "warning");
 return false;

 
}


}
var today = new Date()
var month = parseInt(today.getMonth())+1
console.log(today.getFullYear() +" / "+ month)


