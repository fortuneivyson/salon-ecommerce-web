
function update_profile(){

    auth.onAuthStateChanged((user)=>{
        if(user){

            
            const storage = firebase.storage().ref("users/");
            const file = document.getElementById("user-profile").files[0]; //Upload file
            const upLodeDate = new Date() + "-" + file.upLodeDate;
            const metadata ={contentType: file.type};
            const task = storage.child(upLodeDate).put(file, metadata);
        
            task.on("state_changed", function progress(snapshot){
        
                var percentage = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                document.getElementById("prog_status").value = percentage;
                document.getElementById("up-progress").innerHTML = "Upload " + percentage + "%";
            })
            task.then((snapshot)=>snapshot.ref.getDownloadURL()).then((URL)=>{
                console.log(URL);
                db.collection("users").doc(user.uid).collection("ProfileImage").doc(user.uid).set({
        
                    user_image: URL,
                    
                    
                },merge=true).then(()=>{
                    alert("Profile Has Been Successfully Added")
                })
            })
        
         
        
               

        
    }
   
   })


   


  //  var descr = document.getElementById("product-description").value;


}
function register()
{
    
    

  //uploading pp
   const storage = firebase.storage().ref("users/")
    const file = document.getElementById("profilepic").files[0];
    const name = new Date() + "-" + file.name;
    const metadata = {contentType: file.type};
    const task = storage.child(name).put(file,metadata);

    task.on("state_changed", function progress(snapshot){
        var percentage = (snapshot.bytesTransferred /snapshot.totalBytes)* 100;
        document.getElementById("progStatus").value=percentage;
        document.getElementById("upProgress").innerHTML="Upload " + percentage+"%";
    })
    task.then((snapshot)=>snapshot.ref.getDownloadURL()).then((URL)=>{
        console.log(URL)

        var username = document.getElementById("email").value;
    var password = document.getElementById("pw1").value;
    var password2 = document.getElementById("pw2").value;
    var name = document.getElementById("name").value;
    var address = document.getElementById("address").value;
    var age = document.getElementById("age").value;
    var cnumber = document.getElementById("cnumber").value;
    var gender = document.getElementById("gender").value;

        auth.createUserWithEmailAndPassword(username,password).then(()=>{
        db.collection("users").doc(auth.currentUser.uid).set({
            Email: username, 
            Name: name,
            Address: address,
            Age: age,
            Phone_number: cnumber,
            Gender: gender,
            Profilepic: URL



        },merge=true).then(()=>{
            window.location.href="profile/profile1.html";

        })
        
    });

    })

    
    
    
}
function login()
{
    var username = document.getElementById("email").value;
    var password = document.getElementById("pw1").value;

    auth.signInWithEmailAndPassword(username,password).then(()=>{
        
        window.location.href="profile/profile1.html";

    }).catch(function(error){
        swal("User Login Error", "User does not exist", "error");
    })


}

function signout()
{
    auth.signOut().then(()=>{
        window.location.href="login.html";
        
    }).catch(function(error){
        swal("User Login Error", "Could not sign not", "error");
    })

}