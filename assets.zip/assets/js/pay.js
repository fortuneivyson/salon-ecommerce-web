function makePayment()
{
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var address = document.getElementById("address").value;
    var city = document.getElementById("city").value;
    var prov = document.getElementById("prov").value;
    var zipcode = document.getElementById("zipcode").value;
    var amtPaid = document.getElementById("check-amt").innerText;
    let ref=(Date.now() + Math.random());

    

    var today = new Date();
    var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date+' '+time;


//send payment to db


db.collection("orders").add({
    Name: name,
    Email_address: email,
    Address: address,
    City: city,
    Province: prov,
    Zip_code: zipcode,
    AmountPaid: amtPaid,
    PaymentDate: dateTime,    
    Reference: ref

}).then(()=>{
  swal("Payment Succesful","Thank You for shopping, Ref: "+ref, "success");
})     
}



    
