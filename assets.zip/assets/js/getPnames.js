function getProducts()
{
    let prods=[]

    prods = document.getElementById("nail").innerText;
   
    

console.log(prods)

}