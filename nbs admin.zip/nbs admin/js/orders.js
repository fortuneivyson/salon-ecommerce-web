function SelectAllData()
{
  db.collection('orders').get().then((AllRecords)=>{
      const list = document.getElementById("tbody_orders")
      var div =""
      var html =""
      AllRecords.forEach(
          (CurrentRecord)=>
          {

              div =`
              <tr>

<td>${CurrentRecord.data().AmountPaid}</td>
<td>${CurrentRecord.data().Products}</td>
<td>${CurrentRecord.data().Name}</td>

<td>${CurrentRecord.data().Phone_number}</td>
<td> <div style="position:relative ;display: flex;height: 30px;width: 30px; cursor:pointer;">
<img src="images/icon/update.png" alt="" data-toggle="modal" data-target="#myModal" onclick="viewEachOrder('${CurrentRecord.id}')">
</div></td>





<td id="currtatus">${CurrentRecord.data().Status}</td>
<td>${CurrentRecord.data().PaymentDate}</td>
<td>${CurrentRecord.data().Reference}</td>




</tr>

              `
             html+=div
             list.innerHTML=html
          }

      );

  });
}


var viewItem =""
function viewEachOrder(id)
{
    db.collection("orders").doc(id).get().then((info)=>{
        //get values from database

        document.getElementById("name").value =info.data().Name;
        document.getElementById("phone").value =info.data().Phone_number;
        

        viewItem=id;
    })
}

function updateOrder()
{
    var newName =  document.getElementById("name").value;
   
    var newPhone = document.getElementById("phone").value;
    var status = document.getElementById("orderStatus").value
    
    

    
    db.collection("orders").doc(viewItem).update({
        Name: newName,
        Phone_number: newPhone,
        Status: status,
    }, merge=true).then(()=>{
        swal("Updated","Order details updated","success")
        setTimeout(()=>{
          window.location.reload();
        },2000)
        
    })
}

function yesnoCheck() {
  if (document.getElementById('yesCheck').checked) {
      document.getElementById('ifYes').style.visibility = 'visible';
  } else {
      document.getElementById('ifYes').style.visibility = 'hidden';
  }
}

/*

function updateStatus(id)
{
    var status =  document.getElementById("action").value;
    
    
    db.collection("orders").doc(id).get().then((info)=>{
      //get values from database
      


     db.collection("orders").doc(id).update({
        Status: status,
        
    }, merge=true).then(()=>{
        swal("Updated","Order details updated","success")
        setTimeout(()=>{
          window.location.reload();
        },2000)
        
    })
      

      
  })

    
    
}*/

