function addAdmin()
{
    
    

  //uploading pp
   const storage = firebase.storage().ref("admins/")
    const file = document.getElementById("prof_img").files[0];
    const name = new Date() + "-" + file.name;
    const metadata = {contentType: file.type};
    const task = storage.child(name).put(file,metadata);

    task.on("state_changed", function progress(snapshot){
        var percentage = (snapshot.bytesTransferred /snapshot.totalBytes)* 100;
        document.getElementById("progStatus").value=percentage;
        document.getElementById("upProgress").innerHTML="Upload " + percentage+"%";
    })
    task.then((snapshot)=>snapshot.ref.getDownloadURL()).then((URL)=>{
        console.log(URL)

        var username = document.getElementById("email").value;
    var password = document.getElementById("pw").value;
    var password2 = document.getElementById("pw2").value;
    var name = document.getElementById("name").value;
    var gender = document.getElementById("gender").value;
    var cnumber = document.getElementById("phone").value;
    var status = "Admin";



        auth.createUserWithEmailAndPassword(username,password).then(()=>{
        db.collection("admins").doc(auth.currentUser.uid).set({
            Email: username, 
            Name: name,
            Status: status,
            Phone_number: cnumber,
            Gender: gender,
            Profilepic: URL



        },merge=true).then(()=>{
            swal("Success!", "New Admin has been added", "success")

        })
        
    });

    })

    
    
    
}



function selectAdmins()
{
  db.collection('admins').onSnapshot((AllRecords)=>{
      const list = document.getElementById("tbody_admins")
      var div =""
      var html =""
      AllRecords.forEach(
          (CurrentRecord)=>
          {

              div =`
              <tr>
<td>${CurrentRecord.data().Name}</td>
<td>${CurrentRecord.data().Gender}</td>
<td>${CurrentRecord.data().Email}</td>
<td>${CurrentRecord.data().Phone_number}</td>


<td><a href="#" class="btn" onclick="deleteAdmin('${CurrentRecord.id}')">Delete</a></td>

</tr>
              `
             html+=div
             list.innerHTML=html
          }

      );

  });
}


function adminlogin()
{
    var username = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    auth.signInWithEmailAndPassword(username,password).then(()=>{

        
            window.location.href="dashboard.html";

        
        
        

    }).catch(function(error){
        swal("Admin Login Error", "Wrong Login Details", "error");
    })


}

function adminsignout()
{
    auth.signOut().then(()=>{
        window.location.href="login.html";
        
    }).catch(function(error){
        swal("User Login Error", "Could not sign not", "error");
    })

}