let addToCartButtons = document.getElementsByClassName('btn-primary')
let cartContainer = document.getElementsByTagName('tbody')[0]
let quantityFields = document.getElementsByClassName('num')
let delete_buttons = document.getElementsByClassName('uk-button-danger')

// picking up all the Add-To-Cart buttons




for(let i = 0; i < addToCartButtons.length; i++){
    addToCartButtons[i].addEventListener('click', addToCart)
    
    
}
var prods = "None"
let itemName=" "

// This function helps to add items to our cart
function addToCart(event){

    
    let itemContainer = document.createElement('tr')
    let btn = event.target
    let btnGrandParent = btn.parentElement.parentElement
    let btnParent = btn.parentElement
    let itemImage = btnGrandParent.children[0].src
    itemName = btnParent.children[0].innerText
    let itemPrice = btnParent.children[1].innerText
    
    
    

    itemContainer.innerHTML = `
    <td><span>&nbsp;</span></td>
    
    <td><img class="uk-preserve-width uk-border-circle" src=${itemImage} width="40" alt=""></td>
    <td class="uk-table-link">
        <h3 class = "item-name">${itemName}</h3>
    </td>
    <td class="uk-text-truncate item-price"><h3>${itemPrice}</h3></td>
    <td><input type = 'number' class = 'num' value = '1'></td>
    <td class="uk-text-truncate total-price"><h3>${itemPrice}</h3></td>
    <td><button class="uk-button uk-button-danger" type="button">Remove</button></td>
`
prods = prods+itemName+", "
console.log(prods)

    cartContainer.append(itemContainer)




    // Accessing individual quantity fields
    for(let i = 0; i < quantityFields.length; i++){
        quantityFields[i].value = 1
        quantityFields[i].addEventListener('change', totalCost)
        
                
    }

    // Accessing individual quantity fields
    for(let i = 0; i < delete_buttons.length; i++){
        delete_buttons[i].addEventListener('click', removeItem)
    }

    grandTotal()
}


// This function helps to multiply the quantity and the price
function totalCost(event){
    let quantity = event.target
    quantity_parent = quantity.parentElement.parentElement
    price_field = quantity_parent.getElementsByClassName('item-price')[0]
    total_field = quantity_parent.getElementsByClassName('total-price')[0]
    price_field_content = price_field.innerText.replace('R', '')
    total_field.children[0].innerText = 'R' +  quantity.value * price_field_content
    grandTotal()
    if(isNaN(quantity.value)|| quantity.value <= 0){
        quantity.value = 1
    }

    
    
}

// This function helps to add up the total of the items
let total;
function grandTotal(){
     total = 0
    
    let grand_total = document.getElementsByClassName('grand-total')[0]
    all_total_fields = document.getElementsByClassName('total-price')
    for(let i = 0; i < all_total_fields.length; i++){
        all_prices = Number(all_total_fields[i].innerText.replace('R', ''))
        total+=all_prices
    }
    grand_total.children[0].innerText = "R"+total
    grand_total.children[0].style.fontWeight = 'bold'
    console.log(total)
}


function removeItem(event){
    del_btn = event.target
    del_btn_parent = del_btn.parentElement.parentElement
    del_btn_parent.remove()
    console.log(del_btn)
    grandTotal()
}
    


function displayProducts()
{
    
  //function to dispalyProducts from database

   

   db.collection("products").onSnapshot((info)=>{
    var html=""
    var div=""
    const list = document.getElementById("rowss");


    info.forEach(element => {
     
        div=`<div class = 'col-md-4 col-lg-4'>
        <div class="card" style="width: 18rem;">
        
            <img src="${element.data().Prod_pic}" class="card-img-top" alt="...">
            <div class="card-body">
              <h3 class="card-title">${element.data().Prod_name}</h3>
              <span>${element.data().Description}</span>
              <h4 class="card-text">${element.data().Prod_price}</h4>
              <a class="btn btn-primary" >Add to Cart</a>
            </div>
          </div>
      </div>`
    html += div ;
    list.innerHTML=html;

    

   
   
       
    });
})

}

function checkOut()
{
    if(total==0)
    {
        swal("Checkout Error", "No item was added to cart", "error");
        return false;
    }
    else
    {
    
    window.location.href="checkout.html?Price=" +total+ ""
    }

    console.log(total)
    
}

function finalPrice()
{

    const query = window.location.search
    const url = new URLSearchParams(query)
   
    const price = url.get("Price")
    const shipfee=100.00;
   
    document.getElementById('subtotal').innerHTML = price;
    document.getElementById('check-amt').innerHTML = (parseFloat(price)+shipfee).toFixed(2).toString();
    var vat = 15/100 *(parseFloat(price)+shipfee).toFixed(2)
     document.getElementById('vat').innerHTML = vat.toFixed(2);


    

}

function makePayment()
{

    

    var name = document.getElementById("name").value;
    var phone = document.getElementById("phone").value;
    var email = document.getElementById("email").value;
    var adline1 = document.getElementById("adline1").value;
    var adline2 = document.getElementById("adline2").value;
    var country = document.getElementById("country").value;
    var city = document.getElementById("city").value;
    var prov = document.getElementById("province").value;
    var zipcode = document.getElementById("zipcode").value;
    var amtPaid = document.getElementById("check-amt").innerText;
    let ref=(Date.now() + Math.random());

    

    var today = new Date();
    var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date+' '+time;
    var order = 1000;
    
    
   
        db.collection("orders").add({
            Order_No:  order,
            Email : email,
            Address1: adline1,
            Address2: adline2,
            Country: country,
            Name: name,
            Phone_number: phone,
            
            City: city,
            Province: prov,
            Zip_code: zipcode,
            AmountPaid: amtPaid,
            PaymentDate: dateTime,
            Status: "Pending",
            Products: prods,   
            Reference: ref
        
        }).then(()=>{
            swal("Payment Completed","Your payment was succesfully made, Ref: "+ref, "success");
            setTimeout(()=>{
                window.location.href="index.html"
              },2000)
            
          })     
   


//send payment to db



}

function displayProduct()
{
   

   db.collection("products").onSnapshot((info)=>{
        var html=""
        var div=""
        const list = document.getElementById("productcont");


        info.forEach(element => {
            
        div=`<div class="product col-lg-4 col-md-4 mb-5">
        <div class="prod_img">
          <img src="${element.data().Prod_pic}" alt="">
        </div>
          <h4> ${element.data().Prod_name}</h4>
          <span>${element.data().Description}</span>
         
          <p> ${element.data().Prod_price}</p>
          <button data-toggle="modal" data-target="#myModal" class="updateProd" onclick="viewEachProduct('${element.id}')">Update</button>
          <button class="deleteProd" onclick="deleteProduct('${element.id}')">Remove</button>
          
      </div>`
        html += div ;
        list.innerHTML=html;

      
           
        });
    })
}


