function displayUserInfo()
{
    auth.onAuthStateChanged((user)=>{
        if(user){
            db.collection("users").doc(user.uid).get().then((info)=>{
        
                
              document.querySelector(".uname").innerHTML=info.data().Name;

                document.getElementById("uNameUd").value=info.data().Name;
                document.getElementById("uSnameUd").value=info.data().Surname;
                document.getElementById("uAddress").value=info.data().Address;
                
                
                document.getElementById("uEmailUd").value=info.data().Email;
                document.getElementById("uPhoneUd").value=info.data().Phone_number;

                

               document.getElementById("profile_img").src=info.data().Profilepic;

        })
    }
    })
   
}

function updateUserDetails()
{

}
