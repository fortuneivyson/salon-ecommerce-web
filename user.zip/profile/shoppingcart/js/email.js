function contactus()
{
    var Username =document.getElementById("uname").value;
    var Usubject = document.getElementById("subject").value;
    var Uemail = document.getElementById("email").value;
    var Umessage = document.getElementById("message").value;
    
    

    Email.send({
        Host : "smtp.gmail.com",
        Username : "fortunesoftwaredev@gmail.com",
        Password : "yiflerpqwetrfsdd",
        To : 'fortunesoftwaredev@gmail.com',
        From : Uemail,
        Subject : Username+" "+Usubject,
        Body : Umessage
    })
}
 

