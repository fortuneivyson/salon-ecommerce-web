
   


  //  var descr = document.getElementById("product-description").value;



function register()
{
    
    

  //uploading pp
   const storage = firebase.storage().ref("users/")
    const file = document.getElementById("profilepic").files[0];
    const name = new Date() + "-" + file.name;
    const metadata = {contentType: file.type};
    const task = storage.child(name).put(file,metadata);

    task.on("state_changed", function progress(snapshot){
        var percentage = (snapshot.bytesTransferred /snapshot.totalBytes)* 100;
      ;
    })
    task.then((snapshot)=>snapshot.ref.getDownloadURL()).then((URL)=>{
        console.log(URL)

        var username = document.getElementById("email").value;
    var password = document.getElementById("pw1").value;
    var password2 = document.getElementById("pw2").value;
    var name = document.getElementById("name").value;
    var address = document.getElementById("address").value;
    
    var cnumber = document.getElementById("cnumber").value;
    var gender = document.getElementById("gender").value;
    var status = "Customer";
    var surname = document.getElementById("sname").value;

        auth.createUserWithEmailAndPassword(username,password).then(()=>{
        db.collection("users").doc(auth.currentUser.uid).set({
            Email: username, 
            Name: name,
            Surname: surname,
            Address: address,
            
            Phone_number: cnumber,
            Gender: gender,
            Status: status,
            Profilepic: URL



        },merge=true).then(()=>{
            
            Email.send({
                Host : "smtp.gmail.com",
                Username : "fortunesoftwaredev@gmail.com",
                Password : "yiflerpqwetrfsdd",
                To : 'fortunesoftwaredev@gmail.com',
                From : username ,
                Subject : name+"'s Registration Complete ",
                Body : "Dear "+name+" "+surname+"Thank you for joining NBS, your account is now active"

        }).then(()=>{
            window.location.href="shoppingcart/index.html";
            
          })
        })
        
    });

    })

    
    
    
}
function login()
{
    var username = document.getElementById("email").value;
    var password = document.getElementById("pw1").value;

    auth.signInWithEmailAndPassword(username,password).then(()=>{
        
        window.location.href="shoppingcart/index.html";

    }).catch(function(error){
        swal("User Login Error", "User does not exist", "error");
    })


}
function updateUdetails()
{
    var newName =  document.getElementById("uNameUd").value;
    var newSname =  document.getElementById("uSnameUd").value;
    var newAddr =  document.getElementById("uAddress").value;
    var newEmail = document.getElementById("uEmailUd").value;
    var newPhone = document.getElementById("uPhoneUd").value;
    
    

    
    db.collection("users").doc(auth.currentUser.uid).update({
        Name: newName,
        Surname: newSname,
        Address: newAddr,
        Email: newEmail,
        Phone_number: newPhone,
    }, merge=true).then(()=>{
        swal("Updated","User details updated","success")
        setTimeout(()=>{
          window.location.reload();
        },2000)
        
    })
}
document.querySelector(".uname").innerHTML=info.data().Name;

                document.getElementById("uNameUd").value=info.data().Name;
                document.getElementById("uSnameUd").value=info.data().Surname;
                document.getElementById("uAddress").value=info.data().Address;
                
                
                document.getElementById("uEmailUd").value=info.data().Email;
                document.getElementById("uPhoneUd").value=info.data().Phone_number;
function signout()
{
    auth.signOut().then(()=>{
        window.location.href="../login.html";
        
    }).catch(function(error){
        swal("User Login Error", "Could not sign not", "error");
    })

}