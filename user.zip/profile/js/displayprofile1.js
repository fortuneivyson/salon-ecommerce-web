function displayUserInfo()
{
    auth.onAuthStateChanged((user)=>{
        if(user){
            db.collection("users").doc(user.uid).get().then((info)=>{
        
                
                document.querySelector(".username").innerHTML=info.data().Email;
                document.querySelector(".name").innerHTML=info.data().Name;
                document.querySelector(".age").innerHTML=info.data().Age;
                document.querySelector(".address").innerHTML=info.data().Address;
                document.querySelector(".gender").innerHTML=info.data().Gender;
                document.querySelector(".cnumber").innerHTML=info.data().Phone_number;

                document.getElementById("profile_img").src=info.data().Profilepic;

        })
    }
    })
   
}